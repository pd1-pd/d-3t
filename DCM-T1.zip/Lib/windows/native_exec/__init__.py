from .native_function import create_function

__all__ = ["create_function"]
